import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {

	GradeBook test1;
	GradeBook test2;
	@BeforeEach
	void setUp() throws Exception {
		test1 = new GradeBook(5);
		test2 = new GradeBook(5);
		
		test1.addScore(50.0);
		test1.addScore(75.0);
		test1.addScore(90.0);
		
		test2.addScore(60.0);
		test2.addScore(85.0);
		test2.addScore(100.0);
	}

	@AfterEach
	void tearDown() throws Exception {
		test1 = null;
		test2 = null;
	}

	@Test
	void testAddScore() {
		assertEquals(3.0, test1.getScoreSize(), 0.01);
		assertTrue(test1.toString().equals(" 50.0 75.0 90.0 "));
		
		assertEquals(3.0, test2.getScoreSize(), 0.01);
		assertTrue(test2.toString().equals(" 60.0 85.0 100.0 "));
	}

	@Test
	void testSum() {
		assertEquals(215.0, test1.sum(), .0001);
		assertEquals(245.0, test2.sum(), .0001);
	}

	@Test
	void testMinimum() {
		assertEquals(50.0, test1.minimum(), .0001);
		assertEquals(60.0, test2.minimum(), .0001);
	}

	@Test
	void testFinalScore() {
		assertEquals(165.0, test1.finalScore(), .0001);
		assertEquals(185.0, test2.finalScore(), .0001);
	}
}
