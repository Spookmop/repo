import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		Movie movie = new Movie();
		String title;
		String rating;
		int soldTickets;
		char loop;
	
	do {
		System.out.println("Enter the title of a movie");
		title = input.next();
	
		movie.setTitle(title);
	
	
		System.out.println("Enter the rating of the movie");
		rating = input.next();
		rating = input.next();
	
		movie.setRating(rating);
	
	
		System.out.println("Enter the number of tickets sold for this movie");
		soldTickets = input.nextInt();
	
		movie.setSoldTickets(soldTickets);
	
	
		movie.toString();
	
	
		System.out.println("Do you want to enter another? (y or n)");
		loop = input.next().charAt(0);
	
	} while(loop == 'y' || loop == 'Y');
	System.out.println("Goodbye");
	}
	
}
