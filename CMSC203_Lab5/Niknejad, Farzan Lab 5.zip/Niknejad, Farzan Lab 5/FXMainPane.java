/**
 * @author Farzan Niknejad
 */
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * This panel is the basic panel, inside which other panels are placed.  
 * Before beginning to implement, design the structure of your GUI in order to 
 * understand what panels go inside which ones, and what buttons or other components
 * go in which panels.  
 * @author ralexander
 *
 */
//make the main panel's layout be a VBox
public class FXMainPane extends VBox{

    //student Task #2:
    //  declare five buttons, a label, and a textfield
    Button hello, howdy, chinese, clear, exit;
    TextField textField;
    Label feedback;
    //  declare two HBoxes
    HBox hBox1;
    HBox hBox2;

        //student Task #4:
    DataManager dataManager;
    
    /**
     * The MainPanel constructor sets up the entire GUI in this approach.  Remember to
     * wait to add a component to its containing component until the container has
     * been created.  This is the only constraint on the order in which the following 
     * statements appear.
     */
    FXMainPane() {
        //student Task #2:
        //  instantiate the buttons, label, and textfield
        hello = new Button("Hello"); 
        howdy = new Button("Howdy");
        chinese = new Button("Chinese");
        clear = new Button("Clear");
        exit = new Button("Exit");
        feedback = new Label("FeedBack:");
        textField = new TextField();
        //  instantiate the HBoxes
        hBox1 = new HBox();
        hBox2 = new HBox();

hello.setOnAction(new ButtonHandler());
howdy.setOnAction(new ButtonHandler());
chinese.setOnAction(new ButtonHandler());
clear.setOnAction(new ButtonHandler());
exit.setOnAction(new ButtonHandler());
        //student Task #4:
        //  instantiate the DataManager instance
	dataManager = new DataManager();
        //  set margins and set alignment of the components
        hBox1.setAlignment(Pos.CENTER);
        hBox2.setAlignment(Pos.CENTER);
		
        HBox.setMargin(hello, new Insets(1));
        HBox.setMargin(howdy, new Insets(1));
        HBox.setMargin(chinese, new Insets(1));
        HBox.setMargin(clear, new Insets(1));
        HBox.setMargin(exit, new Insets(1));
        //student Task #3:
        //  add the label and textfield to one of the HBoxes
	hBox2.getChildren().addAll(feedback, textField);
        //  add the buttons to the other HBox
	hBox1.getChildren().addAll(hello, howdy, chinese, clear, exit);
        //  add the HBoxes to this FXMainPanel (a VBox)
	getChildren().addAll(hBox1, hBox2);
    }
    
class ButtonHandler implements EventHandler<ActionEvent>{
        //default constructor is provided by Java

        @Override
public void handle(ActionEvent e) {
        	Button button = (Button)(e.getTarget());
        	
    if(button.getText().equals("Hello")){
        textField.setText(dataManager.getHello());
    }
    else if(button.getText().equals("Howdy")){
        textField.setText(dataManager.getHowdy());
    }
    else if(button.getText().equals("Chinese")){
        textField.setText(dataManager.getChinese());
    }
    else if(button.getText().equals("Clear")){
        textField.setText(" ");
    }
    else if(button.getText().equals("Exit")){
        Platform.exit();
        System.exit(0);
    }
    else{
        textField.setText("How did you even get here?");
    }

           }

    }
}
