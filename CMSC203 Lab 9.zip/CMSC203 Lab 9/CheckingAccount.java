
public class CheckingAccount extends BankAccount{

	static final double FEE = .15;
	
	public CheckingAccount(String name, double amount){
		super(name,amount);
	}
	
	public boolean Withdraw(double amount) {
		double totalAmount = amount+FEE;
		return super.withdraw(totalAmount);
	}
}
