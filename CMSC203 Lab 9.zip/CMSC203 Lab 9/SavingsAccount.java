
public class SavingsAccount extends BankAccount{

	double rate=2.5;
	int savingsNumber=0;
	String accountNumber;
	
	public SavingsAccount(String name, double amount) {
		super(name,amount);
		this.accountNumber = super.getAccountNumber()+ "-"+savingsNumber;
	}
	public void postInterest() {
		
	}
	public String getAccountNumber() {
		return null;
	}
	public SavingsAccount(SavingsAccount account,double balance) {
		
		super(account, balance);
		this.accountNumber = super.getAccountNumber()+"-"+savingsNumber;
	}
}
