/**
 * The purpose of this class is to model a television
 * Farzan Niknejad, 02/20/2020
 * @author Trancendence
 *
 */
public class Television {
	final String MANUFACTURER;//states brand of television
	final int SCREEN_SIZE;//states screen size
	boolean powerOn;//turns on television
	int channel;//placeholder for whatever channel is inputted for television
	int volume;//placeholder for volume control of television

	//states the brand and size of the Television, as well as volume, channel and power status
	Television(String brand, int size){
		MANUFACTURER = brand;
		SCREEN_SIZE = size;
		powerOn = false;
		channel = 2;
		volume = 20;
    }
	//adjusts channel
	public void setChannel(int channel) {
    	this.channel = channel;
    }

	//gets manufacturer
	public String getMANUFACTURER() {
		return MANUFACTURER;
    }
	//gets screensize
	public int getScreenSize() {
    	return SCREEN_SIZE;
    }
	//gets channel
	public int getChannel() {
		return channel;
    }
	//gets volume
    public int getVolume() {
        return volume;
    }
    //toggles power
    public void power() {
        powerOn = !powerOn;
    }
    //increases volume
    public void increaseVolume(){
        volume++;
    }
    //decreases volume
    public void decreaseVolume(){
        volume--;
    }
}