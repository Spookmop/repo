import java.util.Scanner;

public class WindChillTemperature
{
	public static void main(String[] args) 
	{
		
		Scanner input = new Scanner(System.in);
		String programmerName = "Farzan Niknejad";
		
		System.out.println("Wind Chill Calculator");
		
		//Prompts User to enter first variable of formula: Temperature
		System.out.print("Enter the temperature in Fahrenheit between -45�F and 40�F:");
		float temperature = input.nextFloat();
		
		//Prompts User to enter second variable of formula: Wind Speed
		System.out.print("Enter the wind Speed in miles per hour between 5mph and 60mph:");
		float windSpeed = input.nextFloat();

		//Using the formula with the newly inputed variables to calculate Wind Chill
        double windChill = 35.74 + (0.6215 * temperature) - (35.75 * Math.pow(windSpeed, 0.16)) 
        						 + (0.4275 * temperature * Math.pow(windSpeed, 0.16));
		
		System.out.println("The wind chill index is " + windChill);
		System.out.println("Programmer:" + programmerName);
	}
}